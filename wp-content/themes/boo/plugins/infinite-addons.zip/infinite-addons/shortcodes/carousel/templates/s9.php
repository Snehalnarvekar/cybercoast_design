<div class="carousel-nav">
	<button class="flickity-prev-next-button previous"><i class="fa fa-angle-left"></i></button>
	<button class="flickity-prev-next-button next"><i class="fa fa-angle-right"></i></button>
</div>