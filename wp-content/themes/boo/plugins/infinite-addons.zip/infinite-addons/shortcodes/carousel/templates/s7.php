<div class="carousel-nav">
	<button class="flickity-prev-next-button previous"><i class="fa fa-long-arrow-left"></i></button>
	<button class="flickity-prev-next-button next"><i class="fa fa-long-arrow-right"></i></button>
</div>