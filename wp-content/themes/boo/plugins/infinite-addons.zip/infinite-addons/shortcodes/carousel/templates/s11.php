<div class="carousel-nav carousel-nav-style11 text-center mb-60 <?php echo $scheme; ?>">
	<a href="javascript:void(0)" class="btn btn-naked flickity-prev-next-button previous"><i class="fa fa-long-arrow-left"></i></a>
	<a href="javascript:void(0)" class="btn btn-naked flickity-prev-next-button next"><i class="fa fa-long-arrow-right"></i></a>
</div><!-- /.carousel-nav -->