<div class="carousel-nav text-center mb-60">
	<a href="javascript:void(0)" class="btn flickity-prev-next-button previous"><i class="fa fa-angle-left"></i></a>
	<a href="javascript:void(0)" class="btn flickity-prev-next-button next"><i class="fa fa-angle-right"></i></a>
</div><!-- /.carousel-nav -->