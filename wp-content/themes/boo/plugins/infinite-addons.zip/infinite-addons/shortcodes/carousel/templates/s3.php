<div class="carousel-nav align-center">
	<a href="#" class="flickity-prev-next-button previous"><i class="fa fa-angle-left"></i></a>
	<a href="#" class="flickity-prev-next-button next"><i class="fa fa-angle-right"></i></a>
</div>